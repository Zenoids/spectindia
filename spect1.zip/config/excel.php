<?php

return [
    'exports' => [
        'exports_folder' => 'exports', // The folder where exported files will be stored
    ],
];
