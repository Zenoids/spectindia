<section class="container">
<div class="row">
    <div class="col">
        <h1>Vision</h1>
        <p>The realization of the values and the spirit of the
Constitution that ensure social justice, liberty,
equality and fraternity among all citizens.</p>
    </div>
    <div class="col">
        <h1>Mission</h1>
        <p>Conduct objective and solution-seeking research that
will empower Indian Muslims and helping them
develop the community as informed and active
citizens of Indian democracy.</p>
    </div>
    <div class="col">
        <h1>Value</h1>
        <p>CARRVE</p>
    </div>
</div>
</section><?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/home-partials/vision.blade.php ENDPATH**/ ?>