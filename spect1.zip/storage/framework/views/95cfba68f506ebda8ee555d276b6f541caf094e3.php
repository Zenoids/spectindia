<table class="table table-striped table-hover">
    <thead>
        <tr>
          <th scope="col">id</th>
          <th scope="col">voter_id</th>
          <th scope="col">Name</th>
          <th scope="col">Mobile no</th>
          <th scope="col">Email</th>
          <th scope="col">Whatsapp Number</th>
          <th scope="col">Facebook Id</th>
          <th scope="col">Twitter Id</th>
          <th scope="col">address</th>
          <th scope="col">Warn #</th>
          <th scope="col">Assembly Constituency</th>
          <th scope="col">Parliament Seat</th>
          <th scope="col">State</th>
          <th scope="col">Contribution Options</th>
          <th scope="col">About Yourself</th>
          <th scope="col">File Uploaded</th>
          
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($volunteer->id); ?></td>
                <td><?php echo e($volunteer->voter_id); ?></td>
                <td><?php echo e($volunteer->name); ?></td>
                <td><?php echo e($volunteer->mobile_no); ?></td>
                <td><?php echo e($volunteer->email); ?></td>
                <td><?php echo e($volunteer->whatsapp_no); ?></td>
                <td><?php echo e($volunteer->facebook_id); ?></td>
                <td><?php echo e($volunteer->twitter_id); ?></td>
                <td><?php echo e($volunteer->address); ?></td>
                <td><?php echo e($volunteer->ward_name_no); ?></td>
                <td><?php echo e($volunteer->assembly_constituency); ?></td>
                <td><?php echo e($volunteer->parliament_seat); ?></td>
                <td><?php echo e($volunteer->state); ?></td>
                <td><?php echo e($volunteer->contribute_options); ?></td>
                <td><?php echo e($volunteer->about_yourself); ?></td>
                <td><a class="btn btn-outline-info" href="<?php echo e(asset('storage/' . $volunteer->file_path)); ?>">View File</a></td>
                <!-- Add more table cells for other fields as needed -->
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/exports/volunteers.blade.php ENDPATH**/ ?>