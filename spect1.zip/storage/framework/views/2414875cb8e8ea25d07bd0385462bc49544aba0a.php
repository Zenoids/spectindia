<h1>
    thank you

</h1><?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/emails/thank_you.blade.php ENDPATH**/ ?>