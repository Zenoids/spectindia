


<aside class=" p-5 bg-light" style="width: 15% ;height:90vh">
<nav class="nav  flex-column " >

    <a class="nav-link active" aria-current="page" href="<?php echo e(route('dashboard.index')); ?>">Home</a>
    <a class="nav-link" href="<?php echo e(route('dashboard.list')); ?>">Volunteers list</a>
    <a class="nav-link" href="/">Back to website</a>
    <a class="nav-link" href="<?php echo e(route('logout')); ?>">logout</a>
  </nav>
</aside><?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/layouts/dashnav.blade.php ENDPATH**/ ?>