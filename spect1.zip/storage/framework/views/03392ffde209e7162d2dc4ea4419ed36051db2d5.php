
<?php $__env->startSection('content'); ?>

<div class="row w-75 mb-5">
  <form class="d-flex" role="search">
    <input class="form-control me-2" name="search" type="search" placeholder="Search by state or constituency" aria-label="Search" value="<?php echo e($search); ?>">
    <button class="btn btn-outline-success" type="submit">Search</button>
  <?php if($search): ?>
      <!-- If $search is true, show the button -->  <a href=<?php echo e(route('dashboard.list')); ?> >
      <button class="ms-2 btn btn-outline-danger" type="button">Reset</button></a>
  
  <?php endif; ?>
  </form>
</div>

<table class="table table-striped table-hover">
    <thead>
        <tr>
          <th scope="col">id</th>
          <th scope="col">Name</th>
          <th scope="col">Voter ID</th>
          <th scope="col">Number</th>
          <th scope="col">Email</th>
          <th scope="col">View uploads</th>
          <th scope="col">Download</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($volunteer->id); ?></td>
                <td><?php echo e($volunteer->name); ?></td>
                <td><?php echo e($volunteer->voter_id); ?></td>
                <td><?php echo e($volunteer->mobile_no); ?></td>
                <td><?php echo e($volunteer->email); ?></td>
                <td> <a href="<?php echo e(asset('storage/' . $volunteer->file_path)); ?>" target="_blank">
                  uploads
              </a></td>
                <td><a href="<?php echo e(route('exportSingleVolunteer', ['id' => $volunteer->id])); ?>" class="btn btn-outline-success">Download Entry</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        
      </tbody>
  </table>
  
<div class="w-75 d-flex justify-content-between">
  <?php if(empty($search)): ?>

  <div class="pagination-container">
    <ul class="pagination">
        <li class="page-item <?php echo e($volunteers->onFirstPage() ? 'disabled' : ''); ?>">
            <a class="page-link" href="<?php echo e($volunteers->previousPageUrl()); ?>" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
            </a>
        </li>

        <?php for($i = 1; $i <= $volunteers->lastPage(); $i++): ?>
            <li class="page-item <?php echo e($i == $volunteers->currentPage() ? 'active' : ''); ?>">
                <a class="page-link" href="<?php echo e($volunteers->url($i)); ?>"><?php echo e($i); ?></a>
            </li>
        <?php endfor; ?>

        <li class="page-item <?php echo e($volunteers->currentPage() == $volunteers->lastPage() ? 'disabled' : ''); ?>">
            <a class="page-link" href="<?php echo e($volunteers->nextPageUrl()); ?>" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
            </a>
        </li>
    </ul>
  </div><?php endif; ?>
  <a class="float-end" href="<?php echo e(route('list.export')); ?>"> <button class="mx-auto btn btn-success justify-content-end">Download all entries
  </button></a>


</div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/dashboard/list.blade.php ENDPATH**/ ?>