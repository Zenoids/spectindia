
<?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>