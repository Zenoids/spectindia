<header class="masthead">
    <div class="container px-4 px-lg-5 h-100">
        <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
            <div class="col-lg-8 align-self-end">
                <h1 class="text-white font-weight-bold">Study on Social, Political, Economic,
                    Cultural and Technology Aspects (SPECT)</h1>
                <hr class="divider" />
            </div>
            <div class="col-lg-8 align-self-baseline">
                <p class="text-white-75 mb-5">Statistics and analogies shaping your way through survey reports, demographic
                    studies and data-driven analysis.
                </p>
                <!-- <a class="btn btn-primary btn-xl" href="#about">Find Out More</a> -->
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/home-partials/hero.blade.php ENDPATH**/ ?>