<div class="container-fluid bg-light pt-5 py-5 z-depth-1 border-bottom row">
<div class="col-1 col-lg-3"></div>
 
<section class="p-md-3 col-10 col-lg-6  mx-auto">
    <div class="row  ">
      <h3 class="text-center font-weight-bold mb-5">Important areas
        of Focus</h3>
      <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Data Tank
        </h6>

      </div>
      <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Research Intern
        </h6>

      </div>
      <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Survey Volunteers
        </h6>

      </div>
      <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Library and archives
        </h6>

      </div>
      <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Visiting fellows
        </h6>

      </div>
      <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Partnership Programs
        </h6>

      </div>
      <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Themes, Projects and initiatives

        </div>
        <div class="col-lg-4 text-center col-md-6 col-6 mb-5">
          <h6 class=" card p-4 myFocus pb-3">
            Funds
          </h6>
  
        </div>
      <div class="col-lg-4 text-center mx-auto col-md-6 col-6 mb-5">
        <h6 class=" card p-4 myFocus ">
          Trainings, Events and campaigns
        </h6>

      </div>
    </div>
  </section>    <div class="col-1 col-lg-3"></div>

</div>


<!-- 


<div id="carouselExampleAutoplaying" class="carousel slide container" data-bs-ride="carousel">
  <div class="carousel-inner">

    <div class="carousel-item active">
      <div class="row">
        <div class="col">

          <div class=" text-center 5">
            <h4 class="text-muted card p-5 mb-3">
              Data Tank
            </h4>

          </div>

        </div>
        <div class="col">

          <div class=" text-center 5">
            <h4 class="text-muted card p-5 mb-3">
              Research Intern
            </h4>

          </div>
        </div>
        <div class="col">
          <div class=" text-center 5">
            <h4 class="text-muted card p-5 mb-3">
              Survey Volunteers
            </h4>

          </div>

        </div>
      
      </div>
    </div>
    <div class="carousel-item active">
      <div class="row">
        <div class="col">

          <div class=" text-center 5">
            <h4 class="text-muted card p-5 mb-3">
              Data Tank
            </h4>

          </div>

        </div>
        <div class="col">

          <div class=" text-center 5">
            <h4 class="text-muted card p-5 mb-3">
              Research Intern
            </h4>

          </div>
        </div>
        <div class="col">
          <div class=" text-center 5">
            <h4 class="text-muted card p-5 mb-3">
              Survey Volunteers
            </h4>

          </div>

        </div>
       
      </div>
    </div>
    <div class="carousel-item">
      <div class="row">
        <div class="col">slide 5</div>
        <div class="col">slide 6</div>
        <div class="col">slide 7</div>
        <div class="col">slide 8</div>
      </div>
    </div>
  </div>
</div> -->


<!-- <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <h4 class="text-muted mb-3">
         
           Data Tank
        </h4>
        <h4 class="text-muted mb-3">
         
           Data Tank
        </h4>
         <h4 class="text-muted mb-3">
         
           Data Tank
        </h4>
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div> --><?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/home-partials/focus.blade.php ENDPATH**/ ?>