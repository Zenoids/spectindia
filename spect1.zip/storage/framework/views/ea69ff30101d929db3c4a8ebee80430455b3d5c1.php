
<?php $__env->startSection('content'); ?>
    
<section>
    <h2>Welcome to Dashboard</h2>
    <h4>Total number of Volunteers registered: <?php echo e($count); ?></h4>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\register-laravel\spect\resources\views/dashboard/index.blade.php ENDPATH**/ ?>