@extends('layouts.dashboard')
@section('content')
    
<section>
    <h2>Welcome to Dashboard</h2>
    <h4>Total number of Volunteers registered: {{$count}}</h4>
</section>
@endsection

