@extends('layouts.app')
@section('title','SPECT FOUNDATION INDIA')
@section('content')
    

@include('home-partials.hero')
@include('home-partials.about')
@include('home-partials.aims')
@include('home-partials.engage')
@include('home-partials.vision')
@include('home-partials.election')
@include('home-partials.strategy')
@include('home-partials.focus')
@include('home-partials.collaboration')

@endsection