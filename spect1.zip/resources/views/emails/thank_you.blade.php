<h1>
    thank you,{{ $volunteer->name }}

     {{-- {{ $name->mobile_no }} --}}
</h1>